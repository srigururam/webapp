import { Component, OnInit, ViewEncapsulation } from "@angular/core";

@Component({
  selector: "app-preview-components",
  templateUrl: "./preview-components.component.html",
  styleUrls: ["./preview-components.component.scss"],
})
export class PreviewComponentsComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
