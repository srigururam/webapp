import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-theming-preview",
  templateUrl: "./theming-preview.component.html",
  styleUrls: ["./theming-preview.component.scss"],
})
export class ThemingPreviewComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
