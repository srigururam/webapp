const icons = [
  {
    icon_name: "dots",
    icon_path: "assets/images/icons/dots.svg",
  },
  {
    icon_name: "twitter",
    icon_path: "assets/images/icons/twitter.svg",
  },
  {
    icon_name: "call",
    icon_path: "assets/images/icons/call.svg",
  },
  {
    icon_name: "linkedin",
    icon_path: "assets/images/icons/linkedin.svg",
  },
  {
    icon_name: "mail",
    icon_path: "assets/images/icons/mail.svg",
  },
  {
    icon_name: "reset",
    icon_path: "assets/images/icons/reset.svg",
  },
  {
    icon_name: "minus",
    icon_path: "assets/images/icons/minus.svg",
  },
  {
    icon_name: "plus",
    icon_path: "assets/images/icons/plus.svg",
  },
  {
    icon_name: "download",
    icon_path: "assets/images/icons/download.svg",
  },
  {
    icon_name: "search",
    icon_path: "assets/images/icons/search.svg",
  },
  {
    icon_name: "video",
    icon_path: "assets/images/icons/video.svg",
  },
  {
    icon_name: "info",
    icon_path: "assets/images/icons/info.svg",
  },
  {
    icon_name: "help",
    icon_path: "assets/images/icons/help.svg",
  },
  {
    icon_name: "info2",
    icon_path: "assets/images/icons/info2.svg",
  },
  {
    icon_name: "close",
    icon_path: "assets/images/icons/close.svg",
  },
  {
    icon_name: "close2",
    icon_path: "assets/images/icons/close2.svg",
  },
  {
    icon_name: "down-arrow",
    icon_path: "assets/images/icons/down-arrow.svg",
  },
  {
    icon_name: "schedule",
    icon_path: "assets/images/icons/schedule.svg",
  },
  {
    icon_name: "favourite",
    icon_path: "assets/images/icons/favourite.svg",
  },
  {
    icon_name: "right-arrow",
    icon_path: "assets/images/icons/right-arrow.svg",
  },
];

export default icons;
