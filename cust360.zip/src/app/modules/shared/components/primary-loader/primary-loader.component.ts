import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-primary-loader',
  templateUrl: './primary-loader.component.html',
  styleUrls: ['./primary-loader.component.scss']
})
export class PrimaryLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
