import { Component, Input, Output, EventEmitter, Renderer2, SimpleChanges, OnInit, ViewEncapsulation } from '@angular/core';
import { fromEvent, Subject } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import * as d3 from 'd3';
import d3Tip from "d3-tip";
@Component({
  selector: 'app-node-graph',
  templateUrl: './node-graph.component.html',
  styleUrls: ['./node-graph.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class NodeGraphComponent implements OnInit {
  @Input() width = 650//435;
  @Input() height = 550//380;
  @Input() containerId = 'knowledge-graph-container';
  @Input() nodes;
  @Input() links;
  @Input() showLables: boolean = false;
  @Input() isSmall: boolean = false;
  @Input() isExpand: boolean = true;
  @Input() showSearch: boolean = false;

  @Output() selectedNode: EventEmitter<any> = new EventEmitter<any>();
  @Output() searchBasedOnNode: EventEmitter<any> = new EventEmitter<any>();
  @Output() selectedLink: EventEmitter<any> = new EventEmitter<any>();
  @Output() zoomRange: EventEmitter<any> = new EventEmitter<any>();
  @Output() deletedNode: EventEmitter<any> = new EventEmitter<any>();
  @Output() selectLinkNode: EventEmitter<any> = new EventEmitter<any>();
  @Output() public nodeClick = new EventEmitter<any>();

  public networkGraph: any;
  public currentZoom = 0.95;
  public unsubscribe$: Subject<any> = new Subject<any>();
  public disableZoomInButton = false;
  public disableZoonOutButton = false;
  public disableZoomResetButton = false;

  constructor(private _renderer: Renderer2) { }

  ngOnInit(): void {
  }

  ngAfterViewInit() {
    const resize$ = fromEvent(window, 'resize');
    resize$.pipe(
      debounceTime(700)
    ).subscribe(() => {
      // console.log('resize');
      if (this.networkGraph) {
        this.networkGraph.resize();
      }
    });
    this.refeshGraph();
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.isExpand && !changes.isExpand.firstChange && changes.isExpand.currentValue !== changes.isExpand.previousValue) {
      if (this.networkGraph) {
        setTimeout(() => {
          // this.refeshGraph();
          this.networkGraph.resize();
        }, 0);
      }
    }
    if (changes.isSmall && !changes.isSmall.firstChange && changes.isSmall.currentValue !== changes.isSmall.previousValue) {
      if (this.networkGraph) {
        setTimeout(() => {
          this.networkGraph.resize();
        }, 750);
      }
    }
    if (changes && changes.showLables && !changes.showLables.firstChange) {
      d3.selectAll('.label').style('opacity', changes.showLables.currentValue ? 1 : 0);
      // d3.selectAll('.labelBackGround').style('opacity', changes.showLables.currentValue ? 1 : 0);
    } else if (changes && changes.nodes && !changes.nodes.firstChange) {
      this.refeshGraph();
    } else if (changes && changes.links && !changes.links.firstChange) {
      this.refeshGraph();
    } else {
      if (this.networkGraph) {
        this.networkGraph.resize();
      }
    }
  }

  refeshGraph() {
    d3.select(`#${this.containerId}`).select('svg').remove();
    setTimeout(() => {
      this.networkGraph = this.renderNetworkGraph();
    }, 100);
  }


  responsivefy(svg, isHeightNotToUpdate = false) {
    const container = d3.select(svg.node().parentNode);
    const width = parseInt(svg.attr('width'), 10);
    const height = parseInt(svg.attr('height'), 10);
    const aspect = width / height;
    // get width of container and resize svg to fit it
    const resize = () => {
      const targetWidth = parseInt(container.style('width') || svg.attr('width'), 10);
      svg.attr('width', targetWidth);
      let targetHeight = targetWidth / aspect;
      if (isHeightNotToUpdate) {
        // Set Container Height as is.
        targetHeight = container.node().getBoundingClientRect().height;
      }
      svg.attr('height', Math.round(targetHeight));
      return {
        widthAspect: targetWidth / width,
        heightAspect: targetHeight / height,
        widht: parseInt(svg.style('width'), 10),
        height: parseInt(svg.style('height'), 10)
      };
    };
    svg.attr('viewBox', '0 0 ' + width + ' ' + height)
      .attr('perserveAspectRatio', 'xMinYMid')
      .call(() => {
        setTimeout(() => {
          resize();
        }, 10);
      });
    return {
      resize,
      widthAspect: parseInt(svg.style('width'), 10) / width,
      heightAspect: parseInt(svg.style('height'), 10) / height
    };
  }

  renderNetworkGraph() {
    const that = this;
    const graph = { nodes: this.nodes, links: this.links };
    const margin = { top: 10, right: 10, bottom: 10, left: 10 };
    const width = this.width - margin.left - margin.right;
    const height = this.height - margin.top - margin.bottom;

    var edgepaths;
    var edgelabels;

    const svgWrapper = d3.select(`#${that.containerId}`).append('svg')
      .attr('width', width + margin.left + margin.right)
      .attr('height', height + margin.top + margin.bottom)
      .style('font-family', `'Roboto', sans-serif`);

    const svg = svgWrapper.append('g');
    var defs = svg.append('defs');
    var filter = defs.append('filter')
      .attr('id', 'solid')
      .attr('x', 0)
      .attr('y', 0)
      .attr('width', 1)
      .attr('height', 1);
    filter.append('feFlood')
      .attr('flood-color', '#666666')
      .attr('result', 'bg');
    var feMerge = filter.append('feMerge');
    // first layer result of blur and offset
    feMerge.append('feMergeNode')
      .attr('in', 'bg');
    // original image on top
    feMerge.append('feMergeNode')
      .attr('in', 'SourceGraphic');

    edgepaths = svg.selectAll(".edgepath")
      .data(graph.links)
      .enter()
      .append('path')
      .attr('class', 'edgepath')
      .attr('id', function (d, i) { return 'edgepath' + i })
      .attr('fill-opacity', 0)
      .attr('stroke-opacity', 0)
      .attr('fill', '#d9c8ae');

    const container = svg.append('g').attr('class', 'root');
    container.append('defs').append('marker')
      .attr('id', 'arrowhead')
      .attr('viewBox', '-0 -5 10 10')
      .attr('refX', 40)
      .attr('refY', 0)
      .attr('orient', 'auto')
      .attr('markerWidth', 8)
      .attr('markerHeight', 8)
      .attr('xoverflow', 'visible')
      .append('svg:path')
      .attr('d', 'M 0,-5 L 8 ,0 L 0,5')
      .attr('fill', '#d9c8ae')
      .attr('stroke', '#d9c8ae');

    // Resize funciton
    const { resize, heightAspect, widthAspect } = this.responsivefy(svgWrapper, true);

    /* Tooltip Start */
    const tip = d3Tip();
    tip.attr("class", "d3-tip")
      .html((d:any) => {
        console.log(d);
        let str = '';
        for(let x in d.similarities) {
          str += `<li>${x} <small> ${d.similarities[x]}</small></li>`;
        }
        return ` 
        <ul class="list-unstyled">${str}
        </ul>`
      });
    svgWrapper.call(tip);
    /* Tooltip End */

    const graphLayout = d3.forceSimulation(graph.nodes)
      .force("charge", d3.forceManyBody().strength(-800))         // This adds repulsion between nodes. Play with the -400 for the repulsion strength
      .force("center", d3.forceCenter(width / 2, height / 2))
      .force('link', d3.forceLink(graph.links).id(function (d: any) { return d.id; }).distance(100).strength(.2))
      .on('tick', ticked);

    function ticked() {
      node.call(updateNode);
      link.call(updateLink);
      edgepaths.attr('d', function (d) {
        return 'M ' + d.source.x + ' ' + d.source.y + ' L ' + d.target.x + ' ' + d.target.y;
      });
    }

    const zoom: any = d3.zoom()
      .scaleExtent([.1, 4])
      .on('zoom', function (iEvent) {
        svg.attr("transform", iEvent.transform)
      });
    svgWrapper.call(zoom);

    const link = container.append('g').attr('class', 'links')
      .selectAll('line')
      .data(graph.links)
      .enter()
      .append('line')
      .attr('d', function (d: any) {
        return `M${d.source.x} ${d.source.y}, L${d.target.x} ${d.target.y}`
      })
      .attr('class', 'edgepath')
      .attr('fill-opacity', 100)
      .attr('stroke-opacity', 100)
      .attr('fill', '#d9c8ae')
      .attr('stroke', '#d9c8ae')
      .attr('marker-end', 'url(#arrowhead)')
      .attr('id', function (d, i) {
        return 'edgepath' + i
      });

    let timeout = null

    edgelabels = container.selectAll(".edgelabel")
      .data(graph.links)
      .enter()
      .append('text')
      // .style("pointer-events", "none")
      .attr('class', 'edgelabel')
      .attr('id', function (d, i) { return 'edgelabel' + i })
      .attr('font-size', 10)
      .attr('fill', '#5A5B5D')
      .attr('dy', -2)
      .on("mouseover", function (event, d) {
        clearTimeout(timeout);
        tip.hide(d, this);
        tip.show(d, this);
      })
      .on("mouseout", function (event, d) {
        // tip.hide(d, this)
        timeout = setTimeout(() => {
          tip.hide(d, this);
        }, 1000);
      });


    edgelabels.append('textPath')
      .attr('xlink:href', function (d, i) { return '#edgepath' + i })
      .style("text-anchor", "middle")
      .attr("startOffset", "50%")
      // .attr('filter','url(#solid)')
      .attr('x', 20)
      .attr('y', 50)
      .text(function (d) { return d.rel_score })

    let node = container.append('g').attr('class', 'nodes')
      .selectAll('g')
      .data(graph.nodes);

    node = createNodes(node);

    node.call(
      d3.drag()
        .on('start', dragstarted)
        .on('drag', dragged)
        .on('end', dragended)
    );

    // var nodeDrag = svg.append("g")
    //         .attr("class", "nodes")
    //         .selectAll("circle")
    //         .data(graph.nodes)
    //         .enter()
    //         .append("circle")
    //         .attr("r", 10);

    // var drag_handler = d3.drag()
    //         .on("start", dragstarted)
    //         .on("drag", dragged)
    //         .on("end", dragended);	

    //     drag_handler(nodeDrag);

    function createNodes(nodeData) {
      let uiNodes = nodeData
        .enter()
        .append('g')
        .attr('id', function (d) { return 'node_' + d.id; })
        .on('click', (e, d) => {
          // console.log(d);
          that.nodeClick.emit({ data: d });
        })
        .attr('isDeleted', false)
        .attr('class', 'node pointer')
      // .on("mouseover", function (d) {
      //   tip.show(d3.select(this).data()[0], this)
      // })
      // .on("mouseout", function (d) {
      //   tip.hide(d3.select(this).data()[0], this)
      // });

      const textGroup = uiNodes.append('g')
        .attr('id', function (d) { return 'node_label_' + d.id; })
        .attr('transform', (d) => `translate(25, 3)`)
        .classed('label', true)
        .style('opacity', 1);

      textGroup.append('text').text((d) => d.name)

      let circles = uiNodes.append('svg:circle')
        .attr('class', 'node_circle')
        .attr('r', d => 24)
        .style('fill', (d, i) => d.color)
        .style('stroke', (d, i) => '')
        .style('stroke-width', 0.8)

      uiNodes.append('image')
        .attr('xlink:href', (d) => (d.gender == 'Male' ? 'assets/images/icons/Dr-M.svg' : 'assets/images/icons/Dr-F.svg'))
        .attr('width', 30)
        .attr('height', 30)
        .attr('transform', (d) => `translate(-15, -15)`);

      function dotme(text, initWidth = 36) {
        text.each(function () {
          var text = d3.select(this);
          // var words = text.text().split(/\s+/);
          var words = text.text().split('');

          var ellipsis = text.text('').append('tspan').attr('class', 'elip').text('...');
          var width = initWidth - ellipsis.node().getComputedTextLength();
          var numWords = words.length;

          var tspan = text.insert('tspan', ':first-child').text(words.join(''));

          while (tspan.node().getComputedTextLength() > width && words.length) {
            words.pop();
            tspan.text(words.join(''));
          }

          if (words.length === numWords) {
            ellipsis.remove();
          }
        });
      }
      return uiNodes;
    }

    function fixna(x) {
      if (isFinite(x)) {
        return x;
      }
      return 0;
    }

    function updateLink(link) {
      link.attr('x1', function (d) { return fixna(d.source.x); })
        .attr('y1', function (d) { return fixna(d.source.y); })
        .attr('x2', function (d) { return fixna(d.target.x); })
        .attr('y2', function (d) { return fixna(d.target.y); });
    }

    function updateNode(node) {
      node.attr('transform', function (d: any) {
        return 'translate(' + fixna(d.x) + ',' + fixna(d.y) + ')';
      });
    }

    function dragstarted(d) {
      d.sourceEvent.stopPropagation();
      if (!d.active) {
        graphLayout.alphaTarget(0.3).restart();
      }
      d.subject.fx = d.x;
      d.subject.fy = d.y;
    }

    function dragged(d) {
      d.subject.fx = d.x;
      d.subject.fy = d.y;
    }

    function dragended(d) {
      if (!d.active) {
        graphLayout.alphaTarget(0);
      }
      d.subject.fx = null;
      d.subject.fy = null;
    }

    function zoomToFit(paddingPercent, transitionDuration = 500) {
      var bounds = container.node().getBBox();
      var parent = container.node().parentElement;
      var fullWidth = parent.clientWidth,
        fullHeight = parent.clientHeight;
      var width = bounds.width,
        height = bounds.height;
      var midX = bounds.x + width / 2,
        midY = bounds.y + height / 2;
      if (width == 0 || height == 0) return; // nothing to fit
      var scale = (paddingPercent || 0.75) / Math.max(width / fullWidth, height / fullHeight);
      var translate = [fullWidth / 2 - scale * midX, fullHeight / 2 - scale * midY];

      console.trace("zoomFit", translate, scale);
      svgWrapper
        .transition()
        .duration(transitionDuration || 0) // milliseconds
        // .call(zoom.translate(translate).scale(scale).event);
        .call(
          zoom.transform,
          d3.zoomIdentity
            .translate(fullWidth / 2, fullHeight / 2)
            .scale(1)
            // .scale(Math.min(8, 0.9 / Math.max((bounds.width) / fullWidth, (bounds.height) / fullHeight)))
            // .translate(-(bounds.x + bounds.width + bounds.x) / 2, -(bounds.y + bounds.height + bounds.y) / 2)
            .translate(translate[0], translate[1])
        );
    }

    function updateZoom(type) {
      if (type === 'in') {
        zoom.scaleBy(svgWrapper.transition().duration(500), 1.2);
      }
      if (type === 'out') {
        zoom.scaleBy(svgWrapper.transition().duration(500), 0.8);
      }
      if (type === 'fit') {
        zoomToFit(0.95);
        // zoom.scaleBy(svg.transition().duration(500), 0.95);
        //zoomToFit(this.currentZoom);
      }
    }
    return {
      resize() {
        let aspect = resize();
        setTimeout(() => {
          updateZoom('fit');
        }, 0);
      },
      updateZoom,
      zoomToFit
    };
  }

  ngOnDestroy() {
    d3.select('body').select('.knowledge-tooltip').style('opacity', 0);
    this.unsubscribe$.next();
    this.unsubscribe$.complete();
  }
}