import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { NovartisService } from '../../services/novartis.service';
import * as data from "../../../../../assets/json/data.json"
import { animate, state, style, transition, trigger } from '@angular/animations';
import { SharedService } from 'src/app/modules/shared/services/shared.service';

@Component({
  selector: 'app-hcp-details',
  templateUrl: './hcp-details.component.html',
  styleUrls: ['./hcp-details.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
  encapsulation: ViewEncapsulation.None
})
export class HcpDetailsComponent implements OnInit {
  public isShowMore = false;
  private _selectedHCPId = null;
  public selectedHCP = null;
  ELEMENT_DATA = [
    { product: 'Luthera', category: 'Retreatment', requests: 60 },
    { product: 'Jira', category: 'Amino Acids', requests: 50 },
    { product: 'Robento', category: 'Administration', requests: 40 },
  ];


  ELEMENT_DATA2 = [
    {"channel": "Medical Journals", "affinity": "Journal of Clinical Oncology" },
    {"channel": "Professional Websites", "affinity": "onclive" },
    {"channel": "Video Presentations by KOLs and Webinars", "affinity": "ESMO" },
  ];


  ELEMENT_DATA1 = [
    { name: 'Dr. Fabio Garcia', growth: '90%', volume: 600, activity: 'Opened Consentyx efficacy email', score: 'Clinical 100' },
    { name: 'Dr. Orrin Troum', growth: '80%', volume: 560, activity: 'Requested for information on Consentyx website', score: 'Thought Leadership 80' },
    { name: 'Dr. Anne Winkler', growth: '70%', volume: 540, activity: 'Watched patient support video on Consentyx website', score: 'Care Team 70' },
    { name: 'Dr. Suzanne Gharib', growth: '60%', volume: 530, activity: 'Watched patient sub groups educational video on Medscape', score: 'Administrative 60' },
    { name: 'Dr. Robin Dore', growth: '50%', volume: 400, activity: 'Watched patient sub groups educational video on Medical Landscape', score: 'Peer Engagement 56' },
    { name: 'Dr. Dong Liu', growth: '40%', volume: 356, activity: 'Opened Consentyx efficacy email, requested information in Consentyx website', score: 'Peer Engagement 40' }
  ];
  displayedColumns: string[] = ['product', 'category', 'requests'];
  dataSource = this.ELEMENT_DATA;
  displayedColumns2: string[] = ['channel', 'affinity'];
  dataSource2 = this.ELEMENT_DATA2;
  displayedColumns1: string[] = ['name', 'growth', 'volume', 'activity', 'score'];
  dataSource1 = this.ELEMENT_DATA1;
  listViewColumnDetails = ['name', 'similarity', 'sameAreaOfIntrest'];
  listViewSubColumnDetails: string[] = ['name', 'influences', 'influencedBy','requests'];
  expandedElement;
  public nodes: any;
  public links: any;
  public showNetworkGraph = false;
  public isMapView = true;
  public showCommonPathway = false;
  constructor(
    private _novartisService: NovartisService,
    private _router: Router,
    private _sharedService: SharedService
  ) {
  }

  ngOnInit(): void {
    this.getHCPList();
  }

  getHCPList() {
    this._sharedService.togglePrimaryLoader(true);
    setTimeout(() => {
      
      this.showNetworkGraph = false;
      this._selectedHCPId = this._novartisService.getSelectedHCPId();
      // this._novartisService.getHCPList().subscribe(next => {
      //   console.log(next)
      // })
      console.log(data.response);
      this.selectedHCP = data.response.hcp_info.find(v => v.id === this._selectedHCPId);
      if(!this.selectedHCP && data.response.hcp_info.length > 0) {
        this.selectedHCP = data.response.hcp_info[0]
      }
      this.links = data.response.association.filter(v => (v.from === this.selectedHCP.id || v.to === this.selectedHCP.id));
      this.nodes = data.response.hcp_info.filter(v => {
        return !!(this.links.find(l => (l.from == v.id || l.to == v.id)));
      })
      if (this.nodes.length && this.links.length) {
        this.nodes.forEach(x => {
          x.id = x.id;
          x.color = '#b8d0f0';
        });
        this.links.forEach(link => {
          link.source = link.from;
          link.target = link.to;
        });
        this.showNetworkGraph = true;
      }
      data.response.hcp_info.forEach((d:any) => {
        // d.data = d;
        d.influences.forEach(di => {
          di.actualData = data.response.hcp_info.find(v => v.id === di.id);
        });
      });
      this._sharedService.togglePrimaryLoader();
    }, 1000);
  }

  onNodeGraphClick($event) {
    // console.log($event);
    if($event.data.id !== this.selectedHCP.id) {
      this._novartisService.setSelectedHCPId($event.data.id);
      this.getHCPList();
    }
  }

}
