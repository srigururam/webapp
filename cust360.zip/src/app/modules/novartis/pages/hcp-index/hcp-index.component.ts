import { Component, OnInit } from '@angular/core';
import { NovartisService } from '../../services/novartis.service';
import * as data from "../../../../../assets/json/data.json"
import { MatTableDataSource } from '@angular/material/table';
import { Route } from '@angular/compiler/src/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SharedService } from 'src/app/modules/shared/services/shared.service';

@Component({
  selector: 'app-hcp-index',
  templateUrl: './hcp-index.component.html',
  styleUrls: ['./hcp-index.component.scss']
})
export class HcpIndexComponent implements OnInit {
  growthOpportunityTableColumn: string[] = ['providerName', 'growthPotential', 'currentSalesVolume', 'recentActivity', 'influencerScore'];
  growthOpportunityTableData : MatTableDataSource<any>;
  championsNetworkTableColumn: string[] = ['checkbox', 'attendeeName', 'probability', 'quintle'];
  championsNetworkTableData : MatTableDataSource<any>;
  championsNetworkData = [{
    name: "Ray West",
    speciality: "Medical Oncology",
    affiliatedHospital: "Riverside Medical Center",
    attendanceProbability: "High",
    scientificSegment: "Academic",
    lastInteraction: "28 Sep 2021"
  }, {
    name: "Bani Bennett",
    speciality: "Medical Cardiology",
    affiliatedHospital: "Star Medical Center",
    attendanceProbability: "High",
    scientificSegment: "Academic",
    lastInteraction: "27 Sep 2019"
  }, {
    name: "Lilly Rose",
    speciality: "Medical Neurology",
    affiliatedHospital: "Hope Medical Center",
    attendanceProbability: "High",
    scientificSegment: "Academic",
    lastInteraction: "21 Mar 2021"
  }];
  selectedTab = 'join_the_movement'
  constructor(
    private _novartisService: NovartisService,
    private _router: Router,
    private _sharedService: SharedService
  ) { }

  ngOnInit(): void {
    this.getHCPList();
  }
 
  getHCPList() {
    // this._novartisService.getHCPList().subscribe(next => {
    //   console.log(next)
    // })
    console.log(data.response);
    this._sharedService.togglePrimaryLoader(true);
    setTimeout(() => {
      this.growthOpportunityTableData = new MatTableDataSource(data.response.hcp_info);
      this.championsNetworkTableData = new MatTableDataSource(this.championsNetworkData);
      this._sharedService.togglePrimaryLoader();
    }, 1000);
  }

  onProviderSelect(hcp) {
    this._novartisService.setSelectedHCPId(hcp.id);
    this._router.navigate(['novartis', 'hcp-details']);
  }

}
