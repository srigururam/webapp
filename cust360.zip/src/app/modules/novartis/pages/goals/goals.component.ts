import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-goals',
  templateUrl: './goals.component.html',
  styleUrls: ['./goals.component.scss']
})
export class GoalsComponent implements OnInit {
  ELEMENT_DATA = [
    { product: 'Luthera', category: 'Retreatment', requests: 60 },
    { product: ' ', category: 'Amino Acids', requests: 50 },
    { product: ' ', category: 'Administration', requests: 40 },
  ];

  ELEMENT_DATA1 = [
    { name: 'Dr. Fabio Garcia', growth: '90%', volume: 600, activity: 'Opened Consentyx efficacy email', score: 'Clinical 100' },
    { name: 'Dr. Orrin Troum', growth: '80%', volume: 560, activity: 'Requested for information on Consentyx website', score: 'Thought Leadership 80' },
    { name: 'Dr. Anne Winkler', growth: '70%', volume: 540, activity: 'Watched patient support video on Consentyx website', score: 'Care Team 70' },
    { name: 'Dr. Suzanne Gharib', growth: '60%', volume: 530, activity: 'Watched patient sub groups educational video on Medscape', score: 'Administrative 60' },
    { name: 'Dr. Robin Dore', growth: '50%', volume: 400, activity: 'Watched patient sub groups educational video on Medical Landscape', score: 'Peer Engagement 56' },
    { name: 'Dr. Dong Liu', growth: '40%', volume: 356, activity: 'Opened Consentyx efficacy email, requested information in Consentyx website', score: 'Peer Engagement 40' },
    // {position: 3, name: 'Lithium', weight: 6.941, symbol: '10'},
    // {position: 4, name: 'Beryllium', weight: 9.0122, symbol: '60'},
    // {position: 5, name: 'Boron', weight: 10.811, symbol: '12'},
  ];
  displayedColumns: string[] = ['product', 'category', 'requests'];
  dataSource = this.ELEMENT_DATA;
  displayedColumns1: string[] = ['name', 'growth', 'volume', 'activity', 'score'];
  dataSource1 = this.ELEMENT_DATA1;
  constructor() { }

  ngOnInit(): void {
  }

}
