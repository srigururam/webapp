import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-novartis',
  templateUrl: './novartis.component.html',
  styleUrls: ['./novartis.component.scss']
})
export class NovartisComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
