import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { NovartisComponent } from './novartis.component';
import { HcpIndexComponent } from './pages/hcp-index/hcp-index.component';
import { HcpDetailsComponent } from './pages/hcp-details/hcp-details.component';
import { GoalsComponent } from './pages/goals/goals.component';

const routes: Routes = [
  {
    path: "novartis",
    component: NovartisComponent,
    children: [
      { path: "", component: GoalsComponent },
      { path: "hcp-index", component: HcpIndexComponent },
      { path: "hcp-details", component: HcpDetailsComponent },
      { path: "**", redirectTo: "/novartis", pathMatch: "full" },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class NovartisRoutingModule { }
