import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NovartisComponent } from './novartis.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { NovartisRoutingModule } from './novartis-routing.module';
import { MaterialModule } from '../material/material.module';
import { GoalsComponent } from './pages/goals/goals.component';
import { HcpIndexComponent } from './pages/hcp-index/hcp-index.component';
import { HcpDetailsComponent } from './pages/hcp-details/hcp-details.component';
import { NodeGraphComponent } from './components/node-graph/node-graph.component';
import { SharedModule } from '../shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    NovartisComponent,
    DashboardComponent,
    GoalsComponent,
    HcpIndexComponent,
    HcpDetailsComponent,
    NodeGraphComponent,
  ],
  imports: [
    CommonModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    NovartisRoutingModule,
    SharedModule
  ]
})
export class NovartisModule { }
