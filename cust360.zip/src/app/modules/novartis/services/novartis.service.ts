import { Injectable } from '@angular/core';
import { HttpWrapperService } from '../../core/services/http-wrapper.service';

@Injectable({
  providedIn: 'root'
})
export class NovartisService {

  private _selectedHCPId = null;

  constructor(private _httpWrapper: HttpWrapperService) { }

  getHCPList() {
    return this._httpWrapper.get("/assets/json/data.json");
  }

  setSelectedHCPId(id = null) {
    this._selectedHCPId = id;
  }

  getSelectedHCPId() {
    return this._selectedHCPId;
  }
}
