#!/bin/sh
nginx -g "daemon off;" -c /etc/nginx/nginx.conf